package com.example.l;

import android.util.Log;

import io.github.libxposed.api.XposedInterface;
import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedModuleInterface;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

/**
 * ModKit 空白模块 — Xposed 模块入口（内部无任何 App 的 Hook，照本文件加功能）
 *
 * ══════════════════ 三步加一个新 App 的 Hook ══════════════════
 *   ① 本文件下部的 TARGETS 表加一行：{ "目标包名", "应用页显示的功能描述" }
 *   ② xposed/scope.list 加同一行包名（LSPosed 作用域 / 设置页“应用”页与角标统计用）
 *   ③ SettingsActivity.APP_DESC 加一条同名映射（应用页卡片显示该描述）
 *   ④ onPackageLoaded() 里加 else-if 分支，调用你写的 hookXxx(cl) 方法
 *
 * ══════════════════ 现成工具（都在本文件底部）══════════════════
 *   load(cl, "类名")                    安全加载目标类（失败=null+日志，不抛异常）
 *   findMethod(cls, "名", 参数个数)      按「名字 + 参数个数」找 declared 方法
 *   findT(cls, "名", 类型...)            按「名字 + 参数类型」精确找（重载多时用这个）
 *   findCtor(cls, 参数个数)              找构造器（配合 hook(ctor).intercept 用）
 *   replaceReturn(cls, "名", 个数, 值)   把方法返回值固定为「值」——最常用
 *   replaceVoid(cls, "名", 个数)         把方法变成空实现
 *   replaceReturnT(cls, "名", 值, 类型..) 同上但按参数类型精确定位
 *   hook(方法).intercept(Hooker)         自定义拦截：proceed() / getArgs() / getThisObject()
 *   invoke / invokeStatic / setField / setIntField / findFirst / newInstanceAny  反射小工具
 *
 * ══════════════════ 开关机制（已内建）══════════════════
 *   hookEnabled() 每 2 秒经 ContentProvider 查询模块设置页勾选状态；
 *   返回 false 时 replaceXxx 自动恢复原行为 —— 设置页改开关无需重启目标 App。
 *   约定：所有自定义 Hook 回调里也先判 hookEnabled()。
 *
 * ══════════════════ 调试 ══════════════════
 *   logcat | grep ModKit      （TAG 常量），或看 LSPosed 管理器日志页 / FPA 的 FPAXP89 日志
 *   完整文档：/storage/emulated/0/MT2/mcp/ModKit空白模板_开发指南.md
 */
public class Main extends XposedModule {

    /** logcat 过滤用 tag */
    private static final String TAG = "ModKit";

    /** 目标应用表：{ 包名, 应用页描述 }（加 App 只改这里 + scope.list + APP_DESC） */
    private static final String[][] TARGETS = {
            // { "com.example.app", "去广告 · 解锁会员" },
    };

    public Main() {
        super();
    }

    @Override
    public void onPackageLoaded(XposedModuleInterface.PackageLoadedParam param) {
        String pkg = param.getPackageName();
        ClassLoader cl = param.getDefaultClassLoader();

        for (String[] t : TARGETS) {
            if (!t[0].equals(pkg)) continue;
            currentPkg = pkg;
            log(Log.INFO, TAG, "Loaded into " + pkg);

            // ── 在这里分发到你的 hook 方法（每个目标一组 try/catch，互不影响）──
            // if ("com.example.app".equals(pkg)) {
            //     try {
            //         hookExampleApp(cl);
            //     } catch (Throwable e) {
            //         log(Log.ERROR, TAG, "hookExampleApp failed", e);
            //     }
            // }
            return;
        }
    }

    // ════════════════ 你的 Hook 写在下面 ════════════════
    // 下面是一个「去广告 + 解锁会员」的最小完整示例（去掉注释块即可跑），
    // 演示四种最常用手法：固定返回值 / 改返回对象的字段 / 返回值置空 / 读参数并给结果。

    /*
    private void hookExampleApp(ClassLoader cl) {
        // ① 解锁会员：isVip() 恒真（无参方法）
        replaceReturn(load(cl, "com.example.app.account.UserInfo"), "isVip", 0, Boolean.TRUE);

        // ② 去广告：先拿到配置对象，再改它的开关字段
        Method m = findT(load(cl, "com.example.app.ad.AdConfig"), "getAdConfig");   // 0 参
        if (m != null) {
            hook(m).intercept(new XposedInterface.Hooker() {
                @Override
                public Object intercept(XposedInterface.Chain chain) throws Throwable {
                    Object r = chain.proceed();               // 先执行原方法
                    if (hookEnabled() && r != null) {
                        setIntField(r, "showSplashAd", 0);    // 开屏广告开关清零
                        setIntField(r, "showFeedAd", 0);      // 信息流广告开关清零
                    }
                    return r;
                }
            });
            log(Log.INFO, TAG, "hooked AdConfig.getAdConfig");
        }

        // ③ 干掉更新弹窗：数据源返回 null
        replaceReturn(load(cl, "com.example.app.update.UpdateInfo"), "getUpdateInfo", 0, null);

        // ④ 高级：读参数 / 看 thisObject / 直接给结果
        Method pay = findMethod(load(cl, "com.example.app.pay.PayManager"), "isPaySuccess", 1);
        if (pay != null) {
            hook(pay).intercept(new XposedInterface.Hooker() {
                @Override
                public Object intercept(XposedInterface.Chain chain) throws Throwable {
                    java.util.List<Object> args = chain.getArgs();   // ⚠ getArgs() 返回 List<Object>
                    Object orderId = args.isEmpty() ? null : args.get(0);
                    log(Log.INFO, TAG, "isPaySuccess(" + orderId + ") intercepted");
                    if (!hookEnabled()) return chain.proceed();
                    return Boolean.TRUE;                             // 直接给结果，不执行原方法
                    // 需要改参数再执行：Object[] na = args.toArray(); na[0] = 新值; return chain.proceed(na);
                }
            });
        }

        // ⑤ 构造器也能 hook（例如某个 View 构造完隐藏自己）
        Constructor<?> ctor = findCtor(load(cl, "com.example.app.ad.AdView"), 1);
        if (ctor != null) {
            hook(ctor).intercept(new XposedInterface.Hooker() {
                @Override
                public Object intercept(XposedInterface.Chain chain) throws Throwable {
                    chain.proceed();
                    if (hookEnabled()) {
                        try { ((android.view.View) chain.getThisObject()).setVisibility(android.view.View.GONE); }
                        catch (Throwable ignored) {}
                    }
                    return null;
                }
            });
        }
    }
    */

    // ══════════════════════ 开关通道（不用改）══════════════════════

    /** 开关查询 Provider（设置页私有偏好的跨进程读取入口） */
    private static final android.net.Uri STATE_URI =
            android.net.Uri.parse("content://com.example.l.hookstate");
    private android.content.ContentResolver resolver;
    private long lastToggleCheck;
    private boolean cachedEnabled = true;
    private boolean toggleLogged;
    /** 当前进程目标包名（onPackageLoaded 设置；同一进程只会加载进一个目标） */
    private String currentPkg;

    /** 取当前进程的 ContentResolver（lazy，ActivityThread.currentApplication） */
    private android.content.ContentResolver resolver() {
        if (resolver != null) return resolver;
        try {
            Object app = Class.forName("android.app.ActivityThread")
                    .getMethod("currentApplication").invoke(null);
            if (app instanceof android.content.Context) {
                resolver = ((android.content.Context) app).getContentResolver();
            }
        } catch (Throwable ignored) {
        }
        return resolver;
    }

    /** 开关判断（2s 缓存）：① 设置页 Provider（跨框架通用）② remote prefs（LSPosed）③ 默认开 */
    private boolean hookEnabled() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastToggleCheck < 2000) return cachedEnabled;
        lastToggleCheck = now;
        try {
            android.content.ContentResolver r = resolver();
            if (r != null) {
                android.os.Bundle b = r.call(STATE_URI, "enabled", currentPkg, null);
                if (b != null && b.containsKey("v")) {
                    boolean e = b.getBoolean("v", true);
                    if (e != cachedEnabled || !toggleLogged) {
                        log(Log.INFO, TAG, "toggle(provider) = " + e);
                        toggleLogged = true;
                    }
                    cachedEnabled = e;
                    return e;
                }
            }
        } catch (Throwable ignored) {
        }
        try {
            android.content.SharedPreferences sp = getRemotePreferences("settings");
            if (sp.contains("hook_" + currentPkg)) {
                cachedEnabled = sp.getBoolean("hook_" + currentPkg, true);
                return cachedEnabled;
            }
        } catch (Throwable ignored) {
        }
        cachedEnabled = true;
        return true;
    }

    // ══════════════════════ 通用工具（不用改）══════════════════════

    /** 安全加载目标类（失败返回 null 并记日志） */
    private Class<?> load(ClassLoader cl, String name) {
        try {
            return cl.loadClass(name);
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "loadClass err: " + name, t);
            return null;
        }
    }

    /** 把方法返回值替换为固定值（按「方法名 + 参数个数」匹配 declared 方法） */
    private void replaceReturn(Class<?> cls, String name, int paramCount, final Object value) {
        if (cls == null) return;
        Method m = findMethod(cls, name, paramCount);
        if (m == null) {
            log(Log.WARN, TAG, "method not found: " + cls.getName() + "." + name + "/" + paramCount);
            return;
        }
        try {
            hook(m).intercept(new XposedInterface.Hooker() {
                @Override
                public Object intercept(XposedInterface.Chain chain) throws Throwable {
                    // 开关关掉时恢复原行为（实时生效，无需重启目标应用）
                    return hookEnabled() ? value : chain.proceed();
                }
            });
            log(Log.INFO, TAG, "replaced->" + value + ": " + cls.getName() + "." + name);
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "replace err: " + cls.getName() + "." + name, t);
        }
    }

    /** replaceReturn 的类型精确版（按参数类型定位，避免同名不同参方法误挂） */
    private void replaceReturnT(Class<?> cls, String name, final Object value, Class<?>... types) {
        Method m = findT(cls, name, types);
        if (m == null) {
            log(Log.WARN, TAG, "method not found: "
                    + (cls == null ? "?" : cls.getName()) + "." + name + "/" + types.length);
            return;
        }
        try {
            hook(m).intercept(new XposedInterface.Hooker() {
                @Override
                public Object intercept(XposedInterface.Chain chain) throws Throwable {
                    return hookEnabled() ? value : chain.proceed();
                }
            });
            log(Log.INFO, TAG, "replaced->" + value + ": " + cls.getName() + "." + name);
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "replace err: " + cls.getName() + "." + name, t);
        }
    }

    /** 把方法变成空实现（返回 null / 不执行原逻辑） */
    private void replaceVoid(Class<?> cls, String name, int paramCount) {
        replaceReturn(cls, name, paramCount, null);
    }

    private static Method findMethod(Class<?> cls, String name, int paramCount) {
        if (cls == null) return null;
        for (Method m : cls.getDeclaredMethods()) {
            if (m.getName().equals(name) && m.getParameterTypes().length == paramCount) {
                return m;
            }
        }
        return null;
    }

    /** 按「方法名 + 参数类型」精确查找 declared 方法（types 为空 = 0 参） */
    private static Method findT(Class<?> cls, String name, Class<?>... types) {
        if (cls == null) return null;
        for (Method m : cls.getDeclaredMethods()) {
            if (!m.getName().equals(name)) continue;
            Class<?>[] ps = m.getParameterTypes();
            if (ps.length != types.length) continue;
            boolean ok = true;
            for (int i = 0; i < ps.length; i++) {
                if (!ps[i].equals(types[i])) { ok = false; break; }
            }
            if (ok) return m;
        }
        return null;
    }

    /** 按方法名找第一个 declared 方法（不校验参数个数） */
    private static Method findFirst(Class<?> cls, String name) {
        if (cls == null) return null;
        for (Method m : cls.getDeclaredMethods()) {
            if (m.getName().equals(name)) return m;
        }
        return null;
    }

    private static Constructor<?> findCtor(Class<?> cls, int paramCount) {
        if (cls == null) return null;
        for (Constructor<?> c : cls.getDeclaredConstructors()) {
            if (c.getParameterTypes().length == paramCount) return c;
        }
        return null;
    }

    // ---- 反射小工具（替代 legacy XposedHelpers，纯 java.lang.reflect，零额外依赖）----

    /** 调用实例方法（按名字+参数个数，含父类查找） */
    private static Object invoke(Object obj, String name, Object... args) throws Exception {
        int n = args == null ? 0 : args.length;
        Class<?> c = obj.getClass();
        while (c != null) {
            for (Method m : c.getDeclaredMethods()) {
                if (m.getName().equals(name) && m.getParameterTypes().length == n) {
                    m.setAccessible(true);
                    return m.invoke(obj, args);
                }
            }
            c = c.getSuperclass();
        }
        throw new NoSuchMethodException(obj.getClass().getName() + "." + name);
    }

    /** 调用静态方法（按名字+参数个数） */
    private static Object invokeStatic(Class<?> cls, String name, Object... args) throws Exception {
        int n = args == null ? 0 : args.length;
        for (Method m : cls.getDeclaredMethods()) {
            if (m.getName().equals(name) && m.getParameterTypes().length == n) {
                m.setAccessible(true);
                return m.invoke(null, args);
            }
        }
        throw new NoSuchMethodException(cls.getName() + "." + name);
    }

    /** 设置对象字段（按名字，含父类查找；int 字段可直接传 Integer） */
    private static void setField(Object obj, String name, Object value) throws Exception {
        Class<?> c = obj.getClass();
        while (c != null) {
            try {
                java.lang.reflect.Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                f.set(obj, value);
                return;
            } catch (NoSuchFieldException e) {
                c = c.getSuperclass();
            }
        }
        throw new NoSuchFieldException(obj.getClass().getName() + "." + name);
    }

    private static void setIntField(Object obj, String name, int value) throws Exception {
        setField(obj, name, Integer.valueOf(value));
    }

    /** 实例化指定类：优先无参构造器（setAccessible），失败走 Unsafe.allocateInstance（纯反射） */
    private static Object newInstanceAny(Class<?> cls) throws Exception {
        try {
            java.lang.reflect.Constructor<?> c = cls.getDeclaredConstructor();
            c.setAccessible(true);
            return c.newInstance();
        } catch (NoSuchMethodException e) {
            Class<?> uCls = Class.forName("sun.misc.Unsafe");
            Object u = uCls.getDeclaredField("theUnsafe").get(null);
            return uCls.getMethod("allocateInstance", Class.class).invoke(u, cls);
        }
    }
}
