# ModKit 空白模板 — 如何给 App 添加 Hook（开发指南）

> 生成：2026-10-09　配套模板：`/storage/emulated/0/MT2/mcp/ModKit空白模板/`
> 适用：LSPosed / FPA（fun.fpa）/ LSPatch 全兼容（libxposed API 100+，纯 Java 8，无 androidx）

---

## 〇、模板里有什么

```
ModKit空白模板/
├── AndroidManifest.xml        # 清单（版本号 / Provider / 图标主题）
├── build.sh                   # 一键构建：aapt2 → javac → d8 → 签名 → modkit-empty-v1.0.0.apk
├── libs/api.jar               # libxposed API（仅编译期）
├── res/                       # 图标 + 设置页资源
├── src/com/example/l/
│   ├── Main.java              # ★ 加 Hook 只改这个文件（顶部有说明注释）
│   ├── SettingsActivity.java  # 设置页 UI（应用页开关/角标，一般不用动）
│   └── HookStateProvider.java # 开关通道（不用动）
└── xposed/
    ├── module.prop            # 模块元数据
    ├── java_init.list         # 入口类：com.example.l.Main（不改）
    └── scope.list             # 作用域包名，一行一个
```

模板已内置（不用写）：
- 完整设置页 UI：底栏磨砂导航 / 应用页勾选开关 / 深色模式
- **开关通道**：设置页勾选 → ContentProvider → Hook 侧实时读（2s 缓存），关开关自动恢复原行为，无需重启目标 App
- **工具箱**：`load / findMethod / findT / findCtor / replaceReturn / replaceReturnT / replaceVoid / invoke / invokeStatic / setField / setIntField / findFirst / newInstanceAny`（见 Main.java 底部）

---

## 一、加一个新 App 的 Hook：四步走

以给假想的 `com.example.app` 加「去广告 + 解锁会员」为例：

### 第 1 步：`Main.java` 底部的 `TARGETS` 表加一行
```java
private static final String[][] TARGETS = {
        { "com.example.app", "去广告 · 解锁会员" },   // ← 加这行
};
```

### 第 2 步：`xposed/scope.list` 加包名（一行一个）
```
com.example.app
```
（这行决定 LSPosed 作用域提示 / 设置页“应用”页是否出现该 App / 底栏角标计数）

### 第 3 步：`SettingsActivity.java` 的 `APP_DESC` 加描述（与第 1 步第二个元素相同即可）
```java
static {
    APP_DESC.put("com.example.app", "去广告 · 解锁会员");
}
```

### 第 4 步：`Main.onPackageLoaded()` 里加分发分支 + 写 hook 方法
```java
@Override
public void onPackageLoaded(PackageLoadedParam param) {
    ...原有循环...
    if ("com.example.app".equals(pkg)) {
        try {
            hookExampleApp(cl);            // ← 你的 hook 方法
        } catch (Throwable e) {
            log(Log.ERROR, TAG, "hookExampleApp failed", e);
        }
    }
}

private void hookExampleApp(ClassLoader cl) {
    // 见下一节的手法
}
```

> 之后：构建 → 安装 → 框架里启用模块并勾选目标 → **强停重开目标 App** 生效。

---

## 二、写 Hook 的四种常用手法

### 手法 ①：固定返回值（最常用，一行搞定）
```java
// isVip() 恒返回 true
replaceReturn(load(cl, "com.example.app.account.UserInfo"), "isVip", 0, Boolean.TRUE);

// isShowAd() 恒返回 false（注意布尔写 Boolean.FALSE）
replaceReturn(load(cl, "com.example.app.ad.AdConfig"), "isShowAd", 0, Boolean.FALSE);

// 返回 null 阻断（例如弹窗数据源）
replaceReturn(load(cl, "com.example.app.update.UpdateInfo"), "getUpdateInfo", 0, null);

// 重载多 / 混淆同名方法多时，用参数类型精确定位：
replaceReturnT(load(cl, "com.example.app.pay.Checker"), "check", Boolean.TRUE,
        load(cl, "com.example.app.pay.Order"), boolean.class);
```

### 手法 ②：把方法变空（拦截副作用）
```java
replaceVoid(load(cl, "com.example.app.report.Reporter"), "reportEvent", 2);
```

### 手法 ③：自定义拦截（读参数 / 改字段 / 改参数 / 看 this）
```java
Method m = findT(load(cl, "com.example.app.ad.AdConfig"), "getAdConfig");  // 0 参
if (m != null) {
    hook(m).intercept(new XposedInterface.Hooker() {
        @Override
        public Object intercept(XposedInterface.Chain chain) throws Throwable {
            Object r = chain.proceed();                 // 先执行原方法
            if (hookEnabled() && r != null) {
                setIntField(r, "showSplashAd", 0);      // 改返回对象的字段
                setIntField(r, "showFeedAd", 0);
            }
            return r;                                   // 也可 return 新对象 / args[0]
        }
    });
}
```

### 手法 ④：改参数 / 构造器
```java
// 改参数：proceed(新参数) —— getArgs() 返回 List<Object>
hook(pay).intercept(new XposedInterface.Hooker() {
    @Override public Object intercept(XposedInterface.Chain chain) throws Throwable {
        java.util.List<Object> args = chain.getArgs();
        if (hookEnabled() && !args.isEmpty() && args.get(0) instanceof String) {
            Object[] na = args.toArray();
            na[0] = "vip_user";                        // 替换第 1 个参数
            return chain.proceed(na);                  // 用新参数执行原方法
        }
        return chain.proceed();
    }
});

// 构造器 hook（View 构造完隐藏自己）
Constructor<?> ctor = findCtor(load(cl, "com.example.app.ad.AdView"), 1);
hook(ctor).intercept(new XposedInterface.Hooker() {
    @Override public Object intercept(XposedInterface.Chain chain) throws Throwable {
        chain.proceed();
        if (hookEnabled()) ((android.view.View) chain.getThisObject()).setVisibility(android.view.View.GONE);
        return null;
    }
});
```

### 工具速查（都在 Main.java 底部）
| 工具 | 用途 |
|---|---|
| `load(cl, "类名")` | 安全加载目标类（失败=null+日志） |
| `findMethod(cls,名,个数)` | 按「名+参数个数」找方法 |
| `findT(cls,名,类型...)` | 按「名+参数类型」精确找（重载多时用） |
| `findFirst(cls,名)` | 按名找第一个（不校验参数） |
| `findCtor(cls,个数)` | 找构造器 |
| `replaceReturn(cls,名,个数,值)` | 固定返回值 |
| `replaceReturnT(cls,名,值,类型..)` | 固定返回值（类型精确定位） |
| `replaceVoid(cls,名,个数)` | 方法置空 |
| `invoke(obj,名,args..)` | 反射调实例方法（含父类） |
| `invokeStatic(cls,名,args..)` | 反射调静态方法 |
| `setField(obj,名,值)` / `setIntField` | 改字段（含父类） |
| `newInstanceAny(cls)` | 实例化（私有构造也能建） |

---

## 三、怎么找到该 hook 哪个方法（逆向定位流程）

1. **反编译**：MT 管理器打开目标 APK → 看 dex / 或 jadx。
2. **关键词定位**：dex 里搜界面文案（“开通会员”“跳过广告”）或接口字段名（`vip` / `ad` / `sign`）。
   - 搜到字符串 → 看引用它的类/方法 → 顺藤摸瓜。
3. **确认签名**：记下 类全名 / 方法名 / **参数个数与类型**（模板的 findT 需要类型精确匹配）。
4. **先试“返回值替换”类**（isXxx / getXxx / canXxx）——性价比最高，一行生效。
5. **行为类逻辑**（布局/流程）再考虑 intercept 改字段 / 改参数。

### 混淆 App 特别注意
- 方法名可能是单字母（`I` `M` `a`），同名不同参方法多 → **必须用 findT 类型精确匹配**。
- **混淆名随大版本变**：模块失效时先看日志里 `method not found: xxx` 的 WARN 行，
  用新版 APK 重新定位同名方法改一下字符串即可。
- 字段名也会变（实战教训：单例字段 `p`→`a`）——setField 失败看异常里的字段名。

---

## 四、开关与调试

- **用户开关**：模块设置页 → “应用”页 → 勾选目标 App。`hookEnabled()` 自动生效。
- **日志**：`logcat | grep ModKit`（本模板 TAG=ModKit）。
  - `Loaded into 包名` —— 模块已被注入目标进程（没有 = 框架作用域没勾/没重启）
  - `replaced->true: 类.方法` —— 每个 hook 安装成功
  - `method not found: 类.方法/n` —— 目标没找到（名字/参数不对，或版本不匹配）
- **排查顺序**：日志没 `Loaded into` → 查框架（LSPosed 勾作用域 / FPA 勾目标 + 模块）→ 强停重开；
  有 Loaded 没 replaced → hook 目标写错；有 replaced 但无效 → 目标方法没被调用或还有别的路径。

---

## 五、已知坑（实战教训，别踩）

1. **api.jar 里没有 legacy XposedHelpers** —— 全部用模板内置反射工具（invoke/setField...），别 import de.robv.*。
2. **`chain.getArgs()` 返回 `List<Object>`**，不是数组；取参数用 `args.get(i)`。
3. **`chain.proceed()` 是 varargs** —— 无参调用合法（原样执行）；改参用 `proceed(newArgs数组)`。
4. **回调里必须判 `hookEnabled()`**（本模板约定），否则设置页开关关了也不生效。
5. **Kotlin 参数类型**（如 `kotlin.jvm.functions.Function1`）必须运行时 `cl.loadClass`，不能写死 import。
6. **每个目标一组 try/catch**，一个 hook 失败别拖垮同进程的其他 hook。
7. **load 目标类在 onPackageLoaded 阶段是安全的**（已实测：类可加载、方法可找）。
8. **往目标 App 注入 UI**（悬浮面板/菜单）比较复杂：要 hook 目标 Activity.onCreate 拿 Context 自绘 View；
   参考 WinHook 的做法（com.window.hook.lunamusic.window）。
9. **构建分发**：`/sdcard/projects/` 下的构建目录会被构建器清理，每次构建前确认文件齐全；
   shell 对中文文件名不可靠，分发用「cd 中文目录 + 相对路径 cp」。
10. **模块版本号三处同步**：AndroidManifest(versionCode+versionName) / xposed/module.prop / build.sh 输出名。

---

## 六、构建与安装

```bash
sh build.sh          # 产物：build/modkit-empty-v1.0.0.apk（同时复制到项目根目录）
```
- 安装后到 LSPosed/FPA 里**启用模块**并**勾选目标应用**，强停重开目标 App。
- 设置页（本模块 App）里也会列出作用域应用，可随时开关每个 App 的 Hook。

---

## 七、将来改包名/应用名（正式化清单）

模板保持 `com.example.l`；正式发布时若要改包名，需同步：
1. `AndroidManifest.xml`：package、Provider authority（`包名.hookstate`）
2. `src/com/example/l/` 目录名 + 3 个 java 的 `package` 行
3. `Main.java` 的 `STATE_URI` 字符串（`content://包名.hookstate`）
4. `xposed/java_init.list`（`包名.Main`）、`xposed/module.prop` 的 id/name
5. `build.sh`：R.java/BuildInfo 的 gen 路径（`$OUT/gen/包名路径/`）与输出文件名

---

## 附：模板与正式版 ModKit 的关系

| | ModKit（正式版） | ModKit 空白模板 |
|---|---|---|
| 目录 | /storage/emulated/0/MT2/mcp/LSP模块模板/ | /storage/emulated/0/MT2/mcp/ModKit空白模板/ |
| Hook | 头条去广告 + 汽水音质/开屏 | 无（纯骨架） |
| 版本 | v1.0.12（vc13） | v1.0.0（vc1） |
| 包名 | com.example.l | com.example.l（相同，**二者不能同时安装**，装一个即可） |
| 开发文档 | 项目进度.md | 本文档 |

> ⚠ 同包名：空白模板装上会覆盖/被正式版覆盖。做新模块时先把本文第七节的改包名走一遍再装。

*文档结束。有新 App 要 hook：从第一节四步走开始。*
